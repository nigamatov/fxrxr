from django.contrib import admin
from .models import UserModel

admin.site.register(UserModel   )

