from django.contrib import admin
from .views import index
from django.urls import path

urlpatterns = [
    path('', index, name='home')
]