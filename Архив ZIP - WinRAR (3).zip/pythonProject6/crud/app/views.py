from django.shortcuts import render
from .models import UserModel

def index(request):
    age = request.POST.get('age')
    people = UserModel.object.object.filtr(st,'-age')
    return render(request, 'app/index.html', context={'people': people})
